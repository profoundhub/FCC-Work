A Pen created at CodePen.io. You can find this one at https://codepen.io/profoundcoder/pen/wGxaKy.

 This was an assignment for FCC: https://www.freecodecamp.com/challenges/build-a-tribute-page

Heavily edited it and added lots of content. 

Forked from [Marwan Medhat](http://codepen.io/MarwanMehat/)'s Pen [Leonardo Da Vinci (CSS Character)](http://codepen.io/MarwanMehat/pen/GZGJYX/).



